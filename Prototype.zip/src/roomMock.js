import threadImage from "./assets/threadImage.jpeg";

const mock = [
  {
    id: 1,
    title: "104003 - חדו״א 1",
    img: "",
  },
  {
    id: 2,
    title: "096411 - למידה חישובית 1",
    img: "",
  },
  {
    id: 3,
    title: "למידת מכונה - ML",
    img: "",
  },
  {
    id: 4,
    title: "234111 - מבוא למדעי המחשב",
    img: "",
  },
  {
    id: 5,
    title: "095140 - תכנון פרויקטים וניהולם",
    img: "",
  },
  {
    id: 6,
    title: "104166 - אלגברה א׳",
    img: "",
  },
  {
    id: 7,
    title: "106725 - אלגברה מולטילינארית",
    img: "",
  },
  {
    id: 8,
    title: "104134 - אלגברה מודרנית ח׳",
    img: "",
  },
];

export default mock;
